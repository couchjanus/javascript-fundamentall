const Data = [
{
    id: 0,
    name: "Cool Cat",
    price: 177,
    picture: "1.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 1,
    name: "Black Cat",
    price: 666,
    picture: "2.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 2,
    name: "Red Cat",
    price: 555,
    picture: "3.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 3,
    name: "Blue Cat",
    price: 444,
    picture: "4.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 4,
    name: "Green Cat",
    price: 333,
    picture: "5.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 5,
    name: "Grey Cat",
    price: 222,
    picture: "6.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 6,
    name: "Orange Cat",
    price: 777,
    picture: "7.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
{
    id: 7,
    name: "Pretty Cat",
    price: 888,
    picture: "8.jpg",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dignissimos, maxime ea excepturi veritatis itaque."
},
];
